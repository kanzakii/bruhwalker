trashtalk_category = menu:add_category("trash talk")
enabled = menu:add_checkbox("enabled", trashtalk_category)

local trash_talk_table = {
	'oof',
	'OOF',
	'thanks for tutorial',
	'bruh kek',
	'ez',
	'uninstall game',
	'super easy',
	'nice try bye bye',
	'sit dog'
}

local function get_table_length(data)
  if type(data) ~= 'table' then
    return 0
  end
  local count = 0
  for _ in pairs(data) do
    count = count + 1
  end
  return count
end

local num_quotes = get_table_length(trash_talk_table)
local last_sent = 0

local function on_draw()
	if menu:get_value(enabled) == 1 then
		if last_sent < game:get_gametime() then
			last_sent = game:get_gametime() + 0.1
			game:send_chat("/all " .. trash_talk_table[math.random(num_quotes)])
		end
	end
end

client:set_event_callback("on_draw", on_draw)